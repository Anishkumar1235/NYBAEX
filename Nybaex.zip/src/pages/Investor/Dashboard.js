import Header from "./Header";

function InvestorDashboard() {
  return (
    <>
      <Header />
    </>
  );
}

export default InvestorDashboard;
