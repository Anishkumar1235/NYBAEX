import Header from "./Header";

function Ready() {
  return (
    <>
      <Header />

      <div class="modal fade" id="addModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
          <div class="modal-content rounded-4">
            <div className="end-0 position-absolute z-1">
              <button
                type="button"
                class="btn-close bg-primary opacity-100 p-3 rounded-circle m-n3"
                data-bs-dismiss="modal"
              ></button>
            </div>
            <div class="modal-body">
              <div className="card-body px-lg-6 px-4 py-3">
                <h2 className="lh-1 mb-4">Add Details</h2>
                <div>
                  <div className="mb-3">
                    <p className="text-dark mb-1 bg-light py-2 text-center rounded-pill">
                      1.1 Content Type Selection
                    </p>
                  </div>
                  <div>
                    <label>Select your type of content</label>
                    <select className="form-control mt-1" name="">
                      <option>TV Show</option>
                      <option>Web Series</option>
                      <option>Movie</option>
                      <option>Short Film</option>
                      <option>Regional</option>
                    </select>
                  </div>
                  <div className="mt-3">
                    <label>Select language</label>
                    <select className="form-control mt-1" name="">
                      <option>Bengali</option>
                      <option>Telugu</option>
                      <option>Marathi</option>
                      <option>Tamil</option>
                      <option>Urdu</option>
                      <option>Gujarati</option>
                      <option>Malayalam</option>
                      <option>Kannada</option>
                      <option>Odia</option>
                      <option>Punjabi</option>
                      <option>Kashmiri</option>
                      <option>Manipuri</option>
                    </select>
                  </div>
                </div>
                <div>
                  <div className="mt-4 mb-3">
                    <p className="text-dark mb-1 bg-light py-2 text-center rounded-pill">
                      1.2 Project Details
                    </p>
                  </div>
                  <div className="mt-2">
                    <label>Enter your project name</label>
                    <input
                      type="text"
                      className="form-control mt-1"
                      placeholder=""
                    />
                  </div>
                  <div className="mt-2">
                    <label>Upload Poster</label>
                    <input type="file" className="form-control mt-1" />
                  </div>
                  <div className="mt-2">
                    <label>Upload Contract</label>
                    <input
                      type="file"
                      className="form-control mt-1"
                      placeholder=""
                    />
                  </div>
                </div>
                <div>
                  <div className="mt-4 mb-3">
                    <p className="text-dark mb-1 bg-light py-2 text-center rounded-pill">
                      1.3 Form Fields for Content Submission
                    </p>
                  </div>
                  <div className="mt-2">
                    <label>Content Descriptions</label>
                    <textarea rows="5" className="form-control mt-1"></textarea>
                  </div>
                  <div className="mt-2">
                    <label>Upload Trailer</label>
                    <input
                      type="file"
                      className="form-control mt-1"
                      placeholder=""
                    />
                  </div>
                  <div className="mt-2">
                    <label>Production House Name</label>
                    <input
                      type="text"
                      className="form-control mt-1"
                      placeholder=""
                    />
                  </div>
                  <div className="mt-2">
                    <label>Producer / Investor</label>
                    <input
                      type="text"
                      className="form-control mt-1"
                      placeholder=""
                    />
                  </div>
                  <div className="mt-2">
                    <label>Director</label>
                    <input
                      type="text"
                      className="form-control mt-1"
                      placeholder=""
                    />
                  </div>
                  <div className="mt-2">
                    <label>Creative Director</label>
                    <input
                      type="text"
                      className="form-control mt-1"
                      placeholder=""
                    />
                  </div>
                  <div className="mt-2">
                    <label>Writer</label>
                    <input
                      type="text"
                      className="form-control mt-1"
                      placeholder=""
                    />
                  </div>
                  <div className="mt-2">
                    <label>Director of Photography (DOP)</label>
                    <input
                      type="text"
                      className="form-control mt-1"
                      placeholder=""
                    />
                  </div>
                  <div className="mt-2">
                    <label>Content Files</label>
                    <input
                      type="text"
                      className="form-control mt-1"
                      placeholder=""
                    />
                  </div>
                  <div className="mt-2">
                    <label>Cast & Crew Details</label>
                    <input
                      type="file"
                      className="form-control mt-1"
                      placeholder=""
                    />
                  </div>
                  <div className="mt-2">
                    <label>Social Media Links & IDs</label>
                    <textarea rows="4" className="form-control mt-1"></textarea>
                  </div>
                  <div className="mt-2">
                    <label>Cast Bite Related to Content</label>
                    <input
                      type="file"
                      className="form-control mt-1"
                      placeholder=""
                    />
                  </div>
                  <div className="mt-2">
                    <label>Cast Bite Related to Content</label>
                    <input
                      type="file"
                      className="form-control mt-1"
                      placeholder=""
                    />
                  </div>
                  <div className="mt-2">
                    <label>Clip Cut (1-3 Minutes)</label>
                    <input
                      type="file"
                      className="form-control mt-1"
                      placeholder=""
                    />
                  </div>
                </div>
                <div>
                  <div className="mt-4 mb-3">
                    <p className="text-dark mb-1 bg-light py-2 text-center rounded-pill">
                      Project Declaration
                    </p>
                  </div>
                  <div className="mt-2">
                    <label>NOC file of all artist and all technicians</label>
                    <input
                      type="file"
                      className="form-control mt-1"
                      placeholder=""
                    />
                  </div>
                  <div className="mt-2">
                    <label>Budget</label>
                    <input type="text" className="form-control mt-1" />
                  </div>
                </div>
                <button class="btn btn-primary btn-lg mt-5 w-100 rounded-3 fs-5 text-dark">
                  Submit
                </button>
              </div>
              <div className="card-footer rounded-4 px-6 pb-4">
                <p className="mb-0 text-center">
                  By submitting you accept our{" "}
                  <a href="#" className="text-inherit fw-semibold">
                    <u>Policies</u>
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mt-2">
        <div>
          <a
            data-bs-toggle="modal"
            data-bs-target="#addModal"
            class="btn btn-dark px-5 rounded-3 mt-3"
          >
            <span className="mx-2">Ready to Releasing</span>
          </a>
        </div>
      </div>

      <section>
        <div className="container">
          <h2 class="mb-4 mt-5">1 Project</h2>
          <div class="row">
            <div class="col-lg-6 col-12">
              <a
                data-bs-toggle="modal"
                data-bs-target="#detailsModal"
                class="card card-bordered mb-4 card-hover cursor-pointer"
              >
                <div class="card-body">
                  <div>
                    <div class="d-xl-flex">
                      <div class="mb-3 mb-md-0">
                        <img
                          src="https://www.91-cdn.com/metareel-images/content/backdrops-6-1729536414437-bG6Prtffazz89cgSNas7IZZZoEz.jpg"
                          alt=""
                          class="icon-shape border rounded-4 object-fit-cover"
                          height="180"
                          width="150"
                        />
                      </div>
                      <div class="ms-xl-3 w-100 mt-3 mt-xl-1 d-flex flex-column justify-content-between">
                        <div class="d-flex justify-content-between mb-3">
                          <div>
                            <span class="badge bg-danger-soft mb-2">
                              Pending
                            </span>
                            <h3 class="mb-1 fs-4">
                              <span class="text-inherit">Vedaa</span>
                            </h3>
                            <div>
                              <span>Ready to Releasing</span>
                            </div>
                          </div>
                        </div>
                        <div>
                          <div class="mb-2 mb-md-0">
                            <span class="me-4">
                              <i class="bi bi-camera-reels"></i>
                              <span class="ms-1">TV Show</span>
                            </span>
                            <span class="me-2">
                              <i class="bi bi-chat-square-quote"></i>
                              <span class="ms-1">English</span>
                            </span>
                            <div>
                              <i class="bi bi-calendar-week me-1"></i>{" "}
                              <span>15/10/2024</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>
        </div>
      </section>

      <div
        class="modal fade"
        id="detailsModal"
        tabindex="-1"
        aria-hidden="true"
      >
        <div class="modal-dialog modal-lg modal-dialog-centered">
          <div class="modal-content rounded-4">
            <div className="end-0 position-absolute z-1">
              <button
                type="button"
                class="btn-close bg-primary opacity-100 p-3 rounded-circle m-n3"
                data-bs-dismiss="modal"
              ></button>
            </div>
            <div class="modal-body">
              <div className="card-body px-lg-6 px-4 py-3">
                <div className="row">
                  <div className="col-lg-6 col-12">
                    <span class="badge bg-danger-soft mb-2">Pending</span>
                    <h3 class="mb-1 fs-4">
                      <span class="text-inherit">Vedaa</span>
                    </h3>
                    <div>
                      <span>New Project</span>
                    </div>
                    <div className="mt-4">
                      <p className="text-dark">1.1 Content Type Selection</p>
                      <ul>
                        <li>
                          Type of content -{" "}
                          <span className="text-danger">TV Show</span>
                        </li>
                        <li>
                          Language -{" "}
                          <span className="text-danger">Bengali</span>
                        </li>
                      </ul>
                    </div>
                    <div className="mt-4">
                      <p className="text-dark">1.2 Project Details</p>
                      <ul>
                        <li>
                          Project Name -{" "}
                          <span className="text-danger">...</span>
                        </li>
                        <li>
                          Poster -{" "}
                          <span className="text-danger">View Poster</span>
                        </li>
                        <li>
                          Contract -{" "}
                          <span className="text-danger">View Contract</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div className="col-lg-6 col-12">
                    <img
                      src="https://www.91-cdn.com/metareel-images/content/backdrops-6-1729536414437-bG6Prtffazz89cgSNas7IZZZoEz.jpg"
                      alt=""
                      class="icon-shape border rounded-4 object-fit-cover w-100"
                      height="350"
                    />
                  </div>
                </div>
                <div className="mt-5">
                  <div className="mt-4">
                    <p className="text-dark">1.3 Multiple Contracts Option</p>
                    <ul>
                      <li>
                        All Contracts -{" "}
                        <span className="text-danger">View All Contracts</span>
                      </li>
                    </ul>
                  </div>
                  <div className="mt-4">
                    <p className="text-dark">1.4 New Project Submission</p>
                    <ul>
                      <li>
                        Content Descriptions -{" "}
                        <span className="text-danger">...</span>
                      </li>
                      <li>
                        Trailer -{" "}
                        <span className="text-danger">View Trailer</span>
                      </li>
                      <li>
                        Production House Name -{" "}
                        <span className="text-danger">...</span>
                      </li>
                      <li>
                        Producer / Investor -{" "}
                        <span className="text-danger">...</span>
                      </li>
                      <li>
                        Director - <span className="text-danger">...</span>
                      </li>
                      <li>
                        Creative Director -{" "}
                        <span className="text-danger">...</span>
                      </li>
                      <li>
                        Writer - <span className="text-danger">...</span>
                      </li>
                      <li>
                        Director of Photography (DOP) -{" "}
                        <span className="text-danger">...</span>
                      </li>
                      <li>
                        Content Files -{" "}
                        <span className="text-danger">View Files</span>
                      </li>
                      <li>
                        Cast & Crew Details -{" "}
                        <span className="text-danger">View File</span>
                      </li>
                      <li>
                        Social Media Links & IDs -{" "}
                        <span className="text-danger">...</span>
                      </li>
                      <li>
                        Cast Bite Related to Content -{" "}
                        <span className="text-danger">View File</span>
                      </li>
                      <li>
                        Clip Cut (1-3 Minutes) -{" "}
                        <span className="text-danger">View Clip Cut</span>
                      </li>
                      <li>
                        NOC file of all artist and all technicians. -{" "}
                        <span className="text-danger">View NOC</span>
                      </li>
                      <li>
                        Budget - <span className="text-danger">...</span>
                      </li>
                    </ul>
                  </div>
                </div>

                <div className="mt-5">
                  <h3>OTT Updates</h3>
                  <span class="badge bg-danger-soft mb-2">Pending</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Ready;
